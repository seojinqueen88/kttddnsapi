#include "hello.h"
#include <stdio.h>

int hello(int id) {
    printf("hello, my id is %d\n", id);
}
