#ifndef __hello_h__
#define __hello_h__

int hello(int id);

#endif
